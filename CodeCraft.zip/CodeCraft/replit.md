# Vezel Studio - Web Design Agency Website

## Overview

Vezel Studio is a modern web design agency website built with a full-stack TypeScript architecture. The application is designed to showcase the agency's services and handle contact form submissions from potential clients. It emphasizes custom-coded solutions over page builders, targeting service-based businesses looking for high-converting websites.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **Styling**: Tailwind CSS with custom design system
- **UI Components**: Radix UI primitives with shadcn/ui component library
- **State Management**: TanStack Query for server state management
- **Forms**: React Hook Form with Zod validation
- **Build Tool**: Vite for development and bundling

### Backend Architecture
- **Runtime**: Node.js with Express.js server
- **Language**: TypeScript with ES modules
- **Database ORM**: Drizzle ORM configured for PostgreSQL
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **Validation**: Zod schemas for type-safe data validation
- **Session Storage**: PostgreSQL session store via connect-pg-simple

### Development Setup
- **Development Server**: Custom Vite integration with Express
- **Hot Module Replacement**: Vite HMR for fast development iteration
- **Build Process**: Vite for client bundling, esbuild for server bundling
- **Environment**: Replit-optimized with development banner integration

## Key Components

### Database Schema
- **Users Table**: Basic user authentication structure with UUID primary keys
- **Contact Submissions Table**: Stores form submissions with business type categorization
- **Schema Validation**: Drizzle-Zod integration for runtime type safety

### API Endpoints
- `POST /api/contact`: Contact form submission with validation
- `GET /api/contact-submissions`: Admin endpoint for viewing submissions

### Storage Layer
- **Memory Storage**: Development fallback using in-memory Map storage
- **Database Storage**: Production ready with Drizzle ORM and PostgreSQL
- **Interface-based Design**: IStorage interface allows easy storage backend switching

### UI/UX Design
- **Design System**: Dark theme with slate color palette
- **Responsive Design**: Mobile-first approach with Tailwind breakpoints
- **Component Library**: Comprehensive shadcn/ui components for consistency
- **Navigation**: Fixed header with mobile hamburger menu
- **Footer**: Multi-column layout with social links and sitemap

### Pages Structure
- **Home**: Hero section with service previews and call-to-action
- **Services**: Detailed service offerings with feature lists
- **Portfolio**: Project showcase with categorization
- **About**: Company story and team information
- **Contact**: Form-based lead capture with business type selection

## Data Flow

### Contact Form Submission
1. User fills contact form with validation
2. React Hook Form handles client-side validation using Zod schema
3. Form data submitted via TanStack Query mutation
4. Express API validates data server-side with same Zod schema
5. Data stored in PostgreSQL via Drizzle ORM
6. Success/error feedback displayed via toast notifications

### Page Navigation
1. Wouter handles client-side routing without page refreshes
2. Navigation state managed through React context
3. Active page highlighting based on current route
4. Mobile menu toggle for responsive navigation

## External Dependencies

### UI and Styling
- **Radix UI**: Accessible component primitives
- **Tailwind CSS**: Utility-first CSS framework
- **Lucide React**: Icon library for consistent iconography
- **class-variance-authority**: Type-safe CSS class variants

### Data and State Management
- **TanStack Query**: Server state synchronization
- **React Hook Form**: Form state and validation
- **Zod**: Runtime type validation and schema definition

### Database and Backend
- **Drizzle ORM**: Type-safe database operations
- **Neon Database**: Serverless PostgreSQL hosting
- **Express.js**: Web server framework
- **connect-pg-simple**: PostgreSQL session storage

### Development Tools
- **Vite**: Fast development server and bundling
- **TypeScript**: Static type checking
- **ESBuild**: Fast JavaScript bundler for production builds

## Deployment Strategy

### Build Process
- **Client Build**: Vite bundles React application to `dist/public`
- **Server Build**: ESBuild bundles Express server to `dist/index.js`
- **Static Assets**: Served from build output directory

### Environment Configuration
- **Database**: CONNECTION_URL environment variable for PostgreSQL
- **Development**: Hot reload with Vite middleware integration
- **Production**: Optimized builds with static file serving

### Database Management
- **Migrations**: Drizzle Kit manages schema migrations in `migrations/` folder
- **Schema**: Centralized in `shared/schema.ts` for client/server sharing
- **Connection**: Neon serverless driver for production scalability

The application is structured as a monorepo with clear separation between client, server, and shared code, making it easy to maintain and scale while providing a solid foundation for a web design agency's online presence.