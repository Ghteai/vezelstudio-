import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { insertContactSubmissionSchema, type InsertContactSubmission } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Mail, Phone, Clock, Send } from "lucide-react";

export default function Contact() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isSubmitted, setIsSubmitted] = useState(false);

  const form = useForm<InsertContactSubmission>({
    resolver: zodResolver(insertContactSubmissionSchema),
    defaultValues: {
      name: "",
      email: "",
      businessType: "",
      message: "",
    },
  });

  const contactMutation = useMutation({
    mutationFn: (data: InsertContactSubmission) => apiRequest("POST", "/api/contact", data),
    onSuccess: () => {
      toast({
        title: "Message Sent Successfully!",
        description: "Thank you for your message! We'll get back to you within 24 hours.",
        variant: "default",
      });
      form.reset();
      setIsSubmitted(true);
      queryClient.invalidateQueries({ queryKey: ["/api/contact-submissions"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error Sending Message",
        description: error.message || "Please try again later.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertContactSubmission) => {
    contactMutation.mutate(data);
  };

  if (isSubmitted) {
    return (
      <div className="pt-16 min-h-screen flex items-center justify-center bg-gradient-hero">
        <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="bg-slate-800/50 p-6 sm:p-8 lg:p-12 rounded-2xl border border-slate-700/50">
            <div className="w-20 h-20 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-full flex items-center justify-center mx-auto mb-6">
              <span className="text-white text-3xl">✓</span>
            </div>
            <h1 className="text-3xl font-bold mb-4">Thank You!</h1>
            <p className="text-xl text-slate-300 mb-6">
              Your message has been sent successfully. We'll review your project details and get back to you within 24 hours.
            </p>
            <Button 
              onClick={() => setIsSubmitted(false)}
              variant="outline"
              className="border-slate-600 text-slate-300 hover:text-slate-50"
            >
              Send Another Message
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-16 min-h-screen">
      {/* Hero Section */}
      <section className="py-16 sm:py-20 bg-gradient-hero">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-6">
            Ready to Get <span className="bg-gradient-to-r from-sky-400 to-violet-500 bg-clip-text text-transparent">Started?</span>
          </h1>
          <p className="text-lg sm:text-xl text-slate-300 max-w-3xl mx-auto px-4">
            Let's discuss your project and see how we can help your business grow online
          </p>
        </div>
      </section>

      {/* Contact Form Section */}
      <section className="py-16 sm:py-20 bg-slate-800/30">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-slate-800/50 p-6 sm:p-8 lg:p-12 rounded-2xl border border-slate-700/50">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-slate-300">Full Name *</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="Enter your full name"
                            className="bg-slate-700/50 border-slate-600 text-slate-50 placeholder-slate-400 focus:ring-sky-500 focus:border-sky-500"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-slate-300">Email Address *</FormLabel>
                        <FormControl>
                          <Input
                            type="email"
                            placeholder="Enter your email"
                            className="bg-slate-700/50 border-slate-600 text-slate-50 placeholder-slate-400 focus:ring-sky-500 focus:border-sky-500"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <FormField
                  control={form.control}
                  name="businessType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-slate-300">Business Type *</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger className="bg-slate-700/50 border-slate-600 text-slate-50 focus:ring-sky-500 focus:border-sky-500">
                            <SelectValue placeholder="Select your business type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent className="bg-slate-800 border-slate-600">
                          <SelectItem value="pool-services">Pool Services</SelectItem>
                          <SelectItem value="roofing">Roofing</SelectItem>
                          <SelectItem value="car-detailing">Car Detailing</SelectItem>
                          <SelectItem value="hvac">HVAC</SelectItem>
                          <SelectItem value="landscaping">Landscaping</SelectItem>
                          <SelectItem value="plumbing">Plumbing</SelectItem>
                          <SelectItem value="cleaning">Cleaning Services</SelectItem>
                          <SelectItem value="other">Other Service Business</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="message"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-slate-300">Project Details *</FormLabel>
                      <FormControl>
                        <Textarea
                          rows={5}
                          placeholder="Tell us about your project, current website (if any), goals, and timeline..."
                          className="bg-slate-700/50 border-slate-600 text-slate-50 placeholder-slate-400 focus:ring-sky-500 focus:border-sky-500 resize-none"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="text-center">
                  <Button
                    type="submit"
                    disabled={contactMutation.isPending}
                    className="inline-flex items-center bg-gradient-to-r from-sky-500 to-violet-600 text-white px-8 py-4 rounded-xl text-lg font-semibold hover:from-sky-600 hover:to-violet-700 transition-all duration-200 shadow-lg hover:shadow-xl transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {contactMutation.isPending ? (
                      <>Sending...</>
                    ) : (
                      <>
                        Send Project Details
                        <Send className="ml-2" size={20} />
                      </>
                    )}
                  </Button>
                </div>
              </form>
            </Form>
            
            <div className="mt-12 pt-8 border-t border-slate-700/50">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 text-center">
                <div>
                  <div className="w-12 h-12 bg-gradient-to-br from-sky-500 to-sky-600 rounded-lg flex items-center justify-center mx-auto mb-3">
                    <Mail className="text-white" size={24} />
                  </div>
                  <h4 className="font-semibold mb-1">Email Us</h4>
                  <p className="text-slate-400 text-sm">hello@vezelstudio.com</p>
                </div>
                <div>
                  <div className="w-12 h-12 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-lg flex items-center justify-center mx-auto mb-3">
                    <Phone className="text-white" size={24} />
                  </div>
                  <h4 className="font-semibold mb-1">Call Us</h4>
                  <p className="text-slate-400 text-sm">(555) 123-4567</p>
                </div>
                <div>
                  <div className="w-12 h-12 bg-gradient-to-br from-violet-500 to-violet-600 rounded-lg flex items-center justify-center mx-auto mb-3">
                    <Clock className="text-white" size={24} />
                  </div>
                  <h4 className="font-semibold mb-1">Response Time</h4>
                  <p className="text-slate-400 text-sm">Within 24 hours</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-gradient-vezel">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">Frequently Asked Questions</h2>
            <p className="text-xl text-slate-300">Common questions about our services</p>
          </div>
          
          <div className="space-y-6">
            <div className="bg-slate-800/30 p-6 rounded-xl border border-slate-700/50">
              <h3 className="text-lg font-semibold mb-2">How long does it take to build a custom website?</h3>
              <p className="text-slate-400">Most projects take 4-8 weeks from start to finish, depending on complexity and scope. We'll provide a detailed timeline during our initial consultation.</p>
            </div>
            
            <div className="bg-slate-800/30 p-6 rounded-xl border border-slate-700/50">
              <h3 className="text-lg font-semibold mb-2">Do you provide ongoing support after launch?</h3>
              <p className="text-slate-400">Yes! We offer ongoing support packages that include updates, security monitoring, performance optimization, and content changes.</p>
            </div>
            
            <div className="bg-slate-800/30 p-6 rounded-xl border border-slate-700/50">
              <h3 className="text-lg font-semibold mb-2">Can you help with SEO and digital marketing?</h3>
              <p className="text-slate-400">Absolutely. All our websites are built with SEO best practices, and we can connect you with trusted partners for ongoing digital marketing needs.</p>
            </div>
            
            <div className="bg-slate-800/30 p-6 rounded-xl border border-slate-700/50">
              <h3 className="text-lg font-semibold mb-2">What makes your approach different from other agencies?</h3>
              <p className="text-slate-400">We hand-code every website instead of using page builders, focus exclusively on service businesses, and prioritize performance and conversions above all else.</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
