import Hero from "@/components/hero";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Code, RefreshCw, Palette, PenTool, Zap, SearchCheck, Wrench, Star } from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-screen">
      <Hero />
      
      {/* Services Preview Section */}
      <section className="py-16 sm:py-20 bg-slate-800/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12 sm:mb-16">
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold mb-4">Our Services</h2>
            <p className="text-lg sm:text-xl text-slate-300 max-w-3xl mx-auto px-4">
              Comprehensive web solutions for service-based businesses
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
            <div className="bg-slate-800/50 p-8 rounded-2xl border border-slate-700/50 hover:border-sky-500/50 transition-all duration-300 group hover:transform hover:scale-105">
              <div className="w-16 h-16 bg-gradient-to-br from-sky-500 to-sky-600 rounded-xl flex items-center justify-center mb-6 group-hover:from-sky-400 group-hover:to-sky-500 transition-all">
                <Code className="text-white" size={32} />
              </div>
              <h3 className="text-xl font-semibold mb-4">Web Design</h3>
              <p className="text-slate-400 mb-6">Custom-coded websites tailored to your business needs. Fast, responsive, and SEO-optimized.</p>
              <ul className="text-sm text-slate-300 space-y-2">
                <li className="flex items-center"><span className="text-emerald-400 mr-2">✓</span> Responsive Design</li>
                <li className="flex items-center"><span className="text-emerald-400 mr-2">✓</span> SEO Optimization</li>
                <li className="flex items-center"><span className="text-emerald-400 mr-2">✓</span> Performance Focus</li>
              </ul>
            </div>

            <div className="bg-slate-800/50 p-8 rounded-2xl border border-slate-700/50 hover:border-violet-500/50 transition-all duration-300 group hover:transform hover:scale-105">
              <div className="w-16 h-16 bg-gradient-to-br from-violet-500 to-violet-600 rounded-xl flex items-center justify-center mb-6 group-hover:from-violet-400 group-hover:to-violet-500 transition-all">
                <RefreshCw className="text-white" size={32} />
              </div>
              <h3 className="text-xl font-semibold mb-4">Website Redesign</h3>
              <p className="text-slate-400 mb-6">Transform your existing website into a modern, high-converting platform.</p>
              <ul className="text-sm text-slate-300 space-y-2">
                <li className="flex items-center"><span className="text-emerald-400 mr-2">✓</span> Modern UI/UX</li>
                <li className="flex items-center"><span className="text-emerald-400 mr-2">✓</span> Conversion Focus</li>
                <li className="flex items-center"><span className="text-emerald-400 mr-2">✓</span> Mobile Optimization</li>
              </ul>
            </div>

            <div className="bg-slate-800/50 p-8 rounded-2xl border border-slate-700/50 hover:border-emerald-500/50 transition-all duration-300 group hover:transform hover:scale-105">
              <div className="w-16 h-16 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-xl flex items-center justify-center mb-6 group-hover:from-emerald-400 group-hover:to-emerald-500 transition-all">
                <Palette className="text-white" size={32} />
              </div>
              <h3 className="text-xl font-semibold mb-4">Branding</h3>
              <p className="text-slate-400 mb-6">Complete brand identity development to make your business stand out.</p>
              <ul className="text-sm text-slate-300 space-y-2">
                <li className="flex items-center"><span className="text-emerald-400 mr-2">✓</span> Brand Strategy</li>
                <li className="flex items-center"><span className="text-emerald-400 mr-2">✓</span> Visual Identity</li>
                <li className="flex items-center"><span className="text-emerald-400 mr-2">✓</span> Brand Guidelines</li>
              </ul>
            </div>

            <div className="bg-slate-800/50 p-8 rounded-2xl border border-slate-700/50 hover:border-orange-500/50 transition-all duration-300 group hover:transform hover:scale-105">
              <div className="w-16 h-16 bg-gradient-to-br from-orange-500 to-orange-600 rounded-xl flex items-center justify-center mb-6 group-hover:from-orange-400 group-hover:to-orange-500 transition-all">
                <PenTool className="text-white" size={32} />
              </div>
              <h3 className="text-xl font-semibold mb-4">Logo Design</h3>
              <p className="text-slate-400 mb-6">Professional logo creation that represents your business perfectly.</p>
              <ul className="text-sm text-slate-300 space-y-2">
                <li className="flex items-center"><span className="text-emerald-400 mr-2">✓</span> Multiple Concepts</li>
                <li className="flex items-center"><span className="text-emerald-400 mr-2">✓</span> Vector Files</li>
                <li className="flex items-center"><span className="text-emerald-400 mr-2">✓</span> Usage Guidelines</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Why Custom Code Section */}
      <section className="py-20 bg-gradient-vezel">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl sm:text-4xl font-bold mb-6">
                Why Custom Code Over Page Builders?
              </h2>
              <div className="space-y-6">
                <div className="flex items-start">
                  <div className="w-12 h-12 bg-gradient-to-br from-sky-500 to-sky-600 rounded-lg flex items-center justify-center mr-4 flex-shrink-0">
                    <Zap className="text-white" size={24} />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold mb-2">Lightning Fast Performance</h3>
                    <p className="text-slate-300">Custom code eliminates bloat and unnecessary plugins, resulting in websites that load 3x faster than page builders.</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="w-12 h-12 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-lg flex items-center justify-center mr-4 flex-shrink-0">
                    <SearchCheck className="text-white" size={24} />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold mb-2">Superior SEO</h3>
                    <p className="text-slate-300">Clean, semantic HTML and optimized code structure help search engines understand and rank your content better.</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="w-12 h-12 bg-gradient-to-br from-violet-500 to-violet-600 rounded-lg flex items-center justify-center mr-4 flex-shrink-0">
                    <Wrench className="text-white" size={24} />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold mb-2">Complete Control</h3>
                    <p className="text-slate-300">No template limitations. Every element is crafted specifically for your business needs and brand identity.</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="relative">
              <div className="bg-slate-800/50 p-8 rounded-2xl border border-slate-700/50">
                <h3 className="text-2xl font-bold mb-6 text-center">Performance Comparison</h3>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm font-medium">Custom Code</span>
                      <span className="text-sm text-emerald-400">98% Score</span>
                    </div>
                    <div className="w-full bg-slate-700 rounded-full h-3">
                      <div className="bg-gradient-to-r from-emerald-500 to-emerald-400 h-3 rounded-full" style={{width: '98%'}}></div>
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm font-medium">WordPress Builders</span>
                      <span className="text-sm text-orange-400">65% Score</span>
                    </div>
                    <div className="w-full bg-slate-700 rounded-full h-3">
                      <div className="bg-gradient-to-r from-orange-500 to-orange-400 h-3 rounded-full" style={{width: '65%'}}></div>
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm font-medium">Wix/Squarespace</span>
                      <span className="text-sm text-red-400">45% Score</span>
                    </div>
                    <div className="w-full bg-slate-700 rounded-full h-3">
                      <div className="bg-gradient-to-r from-red-500 to-red-400 h-3 rounded-full" style={{width: '45%'}}></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 bg-gradient-vezel">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">What Our Clients Say</h2>
            <p className="text-xl text-slate-300">Real results from real businesses</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-slate-800/50 p-8 rounded-2xl border border-slate-700/50">
              <div className="flex items-center mb-4">
                <div className="flex text-yellow-400">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} size={16} fill="currentColor" />
                  ))}
                </div>
              </div>
              <p className="text-slate-300 mb-6 italic">"Our new website loads incredibly fast and we've seen a 40% increase in leads since launch. The custom code approach was definitely worth it."</p>
              <div className="flex items-center">
                <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center mr-4">
                  <span className="text-white font-bold text-sm">MC</span>
                </div>
                <div>
                  <h4 className="font-semibold">Mike Chen</h4>
                  <p className="text-slate-400 text-sm">Owner, Crystal Pool Services</p>
                </div>
              </div>
            </div>

            <div className="bg-slate-800/50 p-8 rounded-2xl border border-slate-700/50">
              <div className="flex items-center mb-4">
                <div className="flex text-yellow-400">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} size={16} fill="currentColor" />
                  ))}
                </div>
              </div>
              <p className="text-slate-300 mb-6 italic">"Vezel Studio transformed our online presence. The website perfectly captures our brand and converts visitors into customers consistently."</p>
              <div className="flex items-center">
                <div className="w-12 h-12 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-full flex items-center justify-center mr-4">
                  <span className="text-white font-bold text-sm">SJ</span>
                </div>
                <div>
                  <h4 className="font-semibold">Sarah Johnson</h4>
                  <p className="text-slate-400 text-sm">CEO, Summit Roofing Co.</p>
                </div>
              </div>
            </div>

            <div className="bg-slate-800/50 p-8 rounded-2xl border border-slate-700/50">
              <div className="flex items-center mb-4">
                <div className="flex text-yellow-400">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} size={16} fill="currentColor" />
                  ))}
                </div>
              </div>
              <p className="text-slate-300 mb-6 italic">"The difference in performance compared to our old WordPress site is night and day. Our Google rankings improved significantly."</p>
              <div className="flex items-center">
                <div className="w-12 h-12 bg-gradient-to-br from-violet-500 to-violet-600 rounded-full flex items-center justify-center mr-4">
                  <span className="text-white font-bold text-sm">DM</span>
                </div>
                <div>
                  <h4 className="font-semibold">David Martinez</h4>
                  <p className="text-slate-400 text-sm">Owner, Elite Auto Detailing</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-slate-800/30">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">Ready to Get Started?</h2>
          <p className="text-xl text-slate-300 mb-8">
            Let's discuss your project and see how we can help your business grow online
          </p>
          <Link href="/contact">
            <Button className="inline-flex items-center bg-gradient-to-r from-sky-500 to-violet-600 text-white px-8 py-4 rounded-xl text-lg font-semibold hover:from-sky-600 hover:to-violet-700 transition-all duration-200 shadow-lg hover:shadow-xl transform hover:scale-105">
              Start Your Project
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}
