import { ExternalLink } from "lucide-react";
import shineBrightImage from "../assets/shine-bright-homes.jpg";
import igniteAutoworksImage from "../assets/ignite-autoworks.jpg";
import ltPoolSpaImage from "../assets/lt-pool-spa.jpg";
import roofingProImage from "../assets/roofing-pro.svg";
import plumbingMastersImage from "../assets/plumbing-masters.svg";
import landscapingProsImage from "../assets/landscaping-pros.svg";

export default function Portfolio() {
  const portfolioItems = [
    {
      id: 1,
      title: "Shine Bright Homes",
      description: "Professional cleaning service website with veteran-owned business focus, featuring responsive design and comprehensive service pages with social media integration.",
      category: "Cleaning Services",
      tags: ["Cleaning Services", "Veteran-Owned", "Mobile Responsive"],
      image: shineBrightImage,
      url: "shinebrighthomes.com"
    },
    {
      id: 2,
      title: "Ignite Autoworks",
      description: "Premier automotive customization shop website featuring service galleries, online booking system, and customer testimonials with modern dark theme design.",
      category: "Automotive",
      tags: ["Auto Services", "Online Booking", "Gallery"],
      image: igniteAutoworksImage,
      url: "ignite-autoworks.com"
    },
    {
      id: 3,
      title: "LT Pool & Spa Services",
      description: "Complete pool and spa service provider website with customer reviews, service quotes, and contact forms optimized for Miami market.",
      category: "Pool Services",
      tags: ["Pool Services", "Customer Reviews", "Quote System"],
      image: ltPoolSpaImage,
      url: "poolandspaservicescorp.com"
    },
    {
      id: 4,
      title: "RoofPro Excellence",
      description: "Comprehensive roofing contractor website with emergency services, insurance claim assistance, project galleries, and 24/7 customer support system.",
      category: "Roofing",
      tags: ["Roofing", "Emergency Services", "Insurance Claims"],
      image: roofingProImage,
      url: "roofpro-services.com"
    },
    {
      id: 5,
      title: "Plumbing Masters",
      description: "Full-service plumbing company website featuring emergency dispatch, service area mapping, customer testimonials, and online quote system.",
      category: "Plumbing",
      tags: ["Plumbing", "24/7 Emergency", "Online Quotes"],
      image: plumbingMastersImage,
      url: "plumbingmasters.com"
    },
    {
      id: 6,
      title: "Green Landscapes",
      description: "Professional landscaping service website with service packages, before/after galleries, customer reviews, and seasonal maintenance programs.",
      category: "Landscaping",
      tags: ["Landscaping", "Design & Install", "Maintenance"],
      image: landscapingProsImage,
      url: "greenlandscapes.com"
    }
  ];

  const getTagColor = (tag: string) => {
    const colors: { [key: string]: string } = {
      "Cleaning Services": "bg-emerald-500/20 text-emerald-300",
      "Veteran-Owned": "bg-blue-500/20 text-blue-300",
      "Mobile Responsive": "bg-sky-500/20 text-sky-300",
      "Auto Services": "bg-orange-500/20 text-orange-300",
      "Online Booking": "bg-sky-500/20 text-sky-300",
      "Gallery": "bg-violet-500/20 text-violet-300",
      "Pool Services": "bg-blue-500/20 text-blue-300",
      "Customer Reviews": "bg-yellow-500/20 text-yellow-300",
      "Quote System": "bg-green-500/20 text-green-300",
      "Roofing": "bg-red-500/20 text-red-300",
      "Emergency Services": "bg-red-600/20 text-red-300",
      "Insurance Claims": "bg-orange-500/20 text-orange-300",
      "Plumbing": "bg-indigo-500/20 text-indigo-300",
      "24/7 Emergency": "bg-red-500/20 text-red-300",
      "Online Quotes": "bg-green-500/20 text-green-300",
      "Landscaping": "bg-green-500/20 text-green-300",
      "Design & Install": "bg-emerald-500/20 text-emerald-300",
      "Maintenance": "bg-lime-500/20 text-lime-300"
    };
    return colors[tag] || "bg-slate-500/20 text-slate-300";
  };

  return (
    <div className="pt-16 min-h-screen">
      {/* Hero Section */}
      <section className="py-16 sm:py-20 bg-gradient-hero">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-6">
            Our <span className="bg-gradient-to-r from-sky-400 to-violet-500 bg-clip-text text-transparent">Portfolio</span>
          </h1>
          <p className="text-lg sm:text-xl text-slate-300 max-w-3xl mx-auto px-4">
            Showcasing custom-coded websites that drive results for local service businesses
          </p>
        </div>
      </section>

      {/* Portfolio Grid */}
      <section className="py-16 sm:py-20 bg-slate-800/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
            {portfolioItems.map((item) => (
              <div key={item.id} className="group cursor-pointer">
                <div className="bg-slate-800/50 rounded-2xl overflow-hidden border border-slate-700/50 hover:border-sky-500/50 transition-all duration-300 transform hover:scale-105">
                  {/* Project Preview */}
                  <div className="aspect-video relative overflow-hidden bg-slate-700">
                    <img 
                      src={item.image} 
                      alt={`${item.title} website design`}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent"></div>
                    <div className="absolute bottom-4 left-4 text-white">
                      <p className="text-sm font-medium">{item.url}</p>
                    </div>
                    <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity">
                      <ExternalLink className="text-white" size={20} />
                    </div>
                  </div>
                  
                  {/* Project Details */}
                  <div className="p-6">
                    <h3 className="text-xl font-semibold mb-2">{item.title}</h3>
                    <p className="text-slate-400 mb-4">{item.description}</p>
                    <div className="flex flex-wrap gap-2">
                      {item.tags.map((tag) => (
                        <span key={tag} className={`px-3 py-1 rounded-full text-sm ${getTagColor(tag)}`}>
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Results Section */}
      <section className="py-16 sm:py-20 bg-gradient-vezel">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12 sm:mb-16">
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold mb-4">Proven Results</h2>
            <p className="text-lg sm:text-xl text-slate-300 px-4">Our custom websites deliver measurable business growth</p>
          </div>
          
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
            <div className="text-center">
              <div className="text-4xl font-bold text-sky-400 mb-2">40%</div>
              <div className="text-slate-300">Average increase in leads</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-emerald-400 mb-2">3x</div>
              <div className="text-slate-300">Faster load times</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-violet-400 mb-2">65%</div>
              <div className="text-slate-300">Improved conversion rates</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-orange-400 mb-2">98%</div>
              <div className="text-slate-300">Client satisfaction rate</div>
            </div>
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-20 bg-slate-800/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">Our Development Process</h2>
            <p className="text-xl text-slate-300">How we create custom websites that perform</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-sky-500 to-sky-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                <span className="text-white font-bold text-xl">1</span>
              </div>
              <h3 className="text-lg font-semibold mb-2">Discovery & Planning</h3>
              <p className="text-slate-400 text-sm">We analyze your business, competitors, and target audience to create a strategic plan.</p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                <span className="text-white font-bold text-xl">2</span>
              </div>
              <h3 className="text-lg font-semibold mb-2">Design & Prototype</h3>
              <p className="text-slate-400 text-sm">Custom designs that reflect your brand and optimize for user experience and conversions.</p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-violet-500 to-violet-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                <span className="text-white font-bold text-xl">3</span>
              </div>
              <h3 className="text-lg font-semibold mb-2">Development & Testing</h3>
              <p className="text-slate-400 text-sm">Hand-coded development with thorough testing across all devices and browsers.</p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-orange-500 to-orange-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                <span className="text-white font-bold text-xl">4</span>
              </div>
              <h3 className="text-lg font-semibold mb-2">Launch & Optimize</h3>
              <p className="text-slate-400 text-sm">Seamless launch with ongoing monitoring, optimization, and support.</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
