import { Code, RefreshCw, Palette, PenTool, Check } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function Services() {
  return (
    <div className="pt-16 min-h-screen">
      {/* Hero Section */}
      <section className="py-16 sm:py-20 bg-gradient-hero">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-6">
            Our <span className="bg-gradient-to-r from-sky-400 to-violet-500 bg-clip-text text-transparent">Services</span>
          </h1>
          <p className="text-lg sm:text-xl text-slate-300 max-w-3xl mx-auto px-4">
            Comprehensive web solutions designed to help your service-based business thrive online
          </p>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-16 sm:py-20 bg-slate-800/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 sm:gap-12">
            
            {/* Web Design Service */}
            <div className="bg-slate-800/50 p-8 rounded-2xl border border-slate-700/50">
              <div className="w-16 h-16 bg-gradient-to-br from-sky-500 to-sky-600 rounded-xl flex items-center justify-center mb-6">
                <Code className="text-white" size={32} />
              </div>
              <h3 className="text-2xl font-bold mb-4">Custom Web Design</h3>
              <p className="text-slate-300 mb-6">
                From concept to launch, we create stunning, high-performing websites tailored specifically to your business needs. Every line of code is written with performance, SEO, and user experience in mind.
              </p>
              <div className="space-y-3 mb-8">
                <div className="flex items-center">
                  <Check className="text-emerald-400 mr-3" size={18} />
                  <span className="text-slate-300">Mobile-first responsive design</span>
                </div>
                <div className="flex items-center">
                  <Check className="text-emerald-400 mr-3" size={18} />
                  <span className="text-slate-300">SEO-optimized code structure</span>
                </div>
                <div className="flex items-center">
                  <Check className="text-emerald-400 mr-3" size={18} />
                  <span className="text-slate-300">Lightning-fast load times</span>
                </div>
                <div className="flex items-center">
                  <Check className="text-emerald-400 mr-3" size={18} />
                  <span className="text-slate-300">Conversion-focused design</span>
                </div>
                <div className="flex items-center">
                  <Check className="text-emerald-400 mr-3" size={18} />
                  <span className="text-slate-300">Custom contact forms & integrations</span>
                </div>
              </div>
              <div className="bg-slate-700/30 p-4 rounded-lg">
                <p className="text-sm text-slate-400">Perfect for: New businesses, complete website rebuilds, brand launches</p>
              </div>
            </div>

            {/* Website Redesign Service */}
            <div className="bg-slate-800/50 p-8 rounded-2xl border border-slate-700/50">
              <div className="w-16 h-16 bg-gradient-to-br from-violet-500 to-violet-600 rounded-xl flex items-center justify-center mb-6">
                <RefreshCw className="text-white" size={32} />
              </div>
              <h3 className="text-2xl font-bold mb-4">Website Redesign</h3>
              <p className="text-slate-300 mb-6">
                Transform your outdated website into a modern, high-converting machine. We analyze your current site, identify improvement opportunities, and rebuild it with custom code for maximum performance.
              </p>
              <div className="space-y-3 mb-8">
                <div className="flex items-center">
                  <Check className="text-emerald-400 mr-3" size={18} />
                  <span className="text-slate-300">Performance audit & optimization</span>
                </div>
                <div className="flex items-center">
                  <Check className="text-emerald-400 mr-3" size={18} />
                  <span className="text-slate-300">Modern UI/UX design</span>
                </div>
                <div className="flex items-center">
                  <Check className="text-emerald-400 mr-3" size={18} />
                  <span className="text-slate-300">Content migration & optimization</span>
                </div>
                <div className="flex items-center">
                  <Check className="text-emerald-400 mr-3" size={18} />
                  <span className="text-slate-300">Improved conversion rates</span>
                </div>
                <div className="flex items-center">
                  <Check className="text-emerald-400 mr-3" size={18} />
                  <span className="text-slate-300">Enhanced mobile experience</span>
                </div>
              </div>
              <div className="bg-slate-700/30 p-4 rounded-lg">
                <p className="text-sm text-slate-400">Perfect for: Outdated websites, poor-performing sites, rebranding projects</p>
              </div>
            </div>

            {/* Branding Service */}
            <div className="bg-slate-800/50 p-8 rounded-2xl border border-slate-700/50">
              <div className="w-16 h-16 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-xl flex items-center justify-center mb-6">
                <Palette className="text-white" size={32} />
              </div>
              <h3 className="text-2xl font-bold mb-4">Complete Branding</h3>
              <p className="text-slate-300 mb-6">
                Build a cohesive brand identity that resonates with your target audience. From strategy to visual elements, we create a comprehensive brand package that sets you apart from competitors.
              </p>
              <div className="space-y-3 mb-8">
                <div className="flex items-center">
                  <Check className="text-emerald-400 mr-3" size={18} />
                  <span className="text-slate-300">Brand strategy & positioning</span>
                </div>
                <div className="flex items-center">
                  <Check className="text-emerald-400 mr-3" size={18} />
                  <span className="text-slate-300">Logo design & variations</span>
                </div>
                <div className="flex items-center">
                  <Check className="text-emerald-400 mr-3" size={18} />
                  <span className="text-slate-300">Color palette & typography</span>
                </div>
                <div className="flex items-center">
                  <Check className="text-emerald-400 mr-3" size={18} />
                  <span className="text-slate-300">Brand guidelines document</span>
                </div>
                <div className="flex items-center">
                  <Check className="text-emerald-400 mr-3" size={18} />
                  <span className="text-slate-300">Marketing materials design</span>
                </div>
              </div>
              <div className="bg-slate-700/30 p-4 rounded-lg">
                <p className="text-sm text-slate-400">Perfect for: New businesses, rebranding, inconsistent brand identity</p>
              </div>
            </div>

            {/* Logo Design Service */}
            <div className="bg-slate-800/50 p-8 rounded-2xl border border-slate-700/50">
              <div className="w-16 h-16 bg-gradient-to-br from-orange-500 to-orange-600 rounded-xl flex items-center justify-center mb-6">
                <PenTool className="text-white" size={32} />
              </div>
              <h3 className="text-2xl font-bold mb-4">Professional Logo Design</h3>
              <p className="text-slate-300 mb-6">
                Create a memorable logo that perfectly represents your business. We design scalable, versatile logos that work across all platforms and marketing materials, from business cards to billboards.
              </p>
              <div className="space-y-3 mb-8">
                <div className="flex items-center">
                  <Check className="text-emerald-400 mr-3" size={18} />
                  <span className="text-slate-300">3-5 initial logo concepts</span>
                </div>
                <div className="flex items-center">
                  <Check className="text-emerald-400 mr-3" size={18} />
                  <span className="text-slate-300">Unlimited revisions</span>
                </div>
                <div className="flex items-center">
                  <Check className="text-emerald-400 mr-3" size={18} />
                  <span className="text-slate-300">Vector files (AI, EPS, SVG)</span>
                </div>
                <div className="flex items-center">
                  <Check className="text-emerald-400 mr-3" size={18} />
                  <span className="text-slate-300">High-res PNG & JPG files</span>
                </div>
                <div className="flex items-center">
                  <Check className="text-emerald-400 mr-3" size={18} />
                  <span className="text-slate-300">Logo usage guidelines</span>
                </div>
              </div>
              <div className="bg-slate-700/30 p-4 rounded-lg">
                <p className="text-sm text-slate-400">Perfect for: New businesses, logo updates, brand refresh projects</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-20 bg-gradient-vezel">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">Why Choose Vezel Studio?</h2>
            <p className="text-xl text-slate-300">We're different from other agencies</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-sky-500 to-sky-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Code className="text-white" size={32} />
              </div>
              <h3 className="text-xl font-bold mb-4">Custom Code Only</h3>
              <p className="text-slate-300">No page builders, no templates. Every website is built from scratch with clean, optimized code.</p>
            </div>
            
            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <span className="text-white font-bold text-2xl">3x</span>
              </div>
              <h3 className="text-xl font-bold mb-4">Faster Performance</h3>
              <p className="text-slate-300">Our custom-coded websites load 3x faster than page builder sites, improving user experience and SEO.</p>
            </div>
            
            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-violet-500 to-violet-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <span className="text-white font-bold text-xl">24/7</span>
              </div>
              <h3 className="text-xl font-bold mb-4">Ongoing Support</h3>
              <p className="text-slate-300">We provide continuous support and maintenance to keep your website running smoothly.</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-slate-800/30">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">Ready to Transform Your Online Presence?</h2>
          <p className="text-xl text-slate-300 mb-8">
            Let's discuss which service is right for your business
          </p>
          <Link href="/contact">
            <Button className="inline-flex items-center bg-gradient-to-r from-sky-500 to-violet-600 text-white px-8 py-4 rounded-xl text-lg font-semibold hover:from-sky-600 hover:to-violet-700 transition-all duration-200 shadow-lg hover:shadow-xl transform hover:scale-105">
              Get Started Today
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}
