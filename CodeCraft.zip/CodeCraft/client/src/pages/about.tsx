import { Code, Handshake, TrendingUp } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function About() {
  return (
    <div className="pt-16 min-h-screen">
      {/* Hero Section */}
      <section className="py-16 sm:py-20 bg-gradient-hero">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-6">
            About <span className="bg-gradient-to-r from-sky-400 to-violet-500 bg-clip-text text-transparent">Vezel Studio</span>
          </h1>
          <p className="text-lg sm:text-xl text-slate-300 max-w-3xl mx-auto px-4">
            We're a specialized web design agency focused on creating high-converting, custom-coded websites for service-based businesses.
          </p>
        </div>
      </section>

      {/* Main About Section */}
      <section className="py-16 sm:py-20 bg-slate-800/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 sm:gap-12 items-center">
            <div>
              <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold mb-6">Our Story</h2>
              <p className="text-xl text-slate-300 mb-6">
                Founded with the belief that every business deserves a website that truly represents their quality and professionalism.
              </p>
              <p className="text-slate-400 mb-8">
                We've made it our mission to help local service businesses stand out online with websites that actually work. Unlike agencies that rely on page builders and templates, we hand-code every website from scratch, ensuring optimal performance, SEO, and user experience.
              </p>
              <p className="text-slate-400 mb-8">
                Our team understands the unique challenges that service-based businesses face in the digital landscape. From pool services to roofing companies, we know what it takes to convert website visitors into paying customers.
              </p>
              
              <div className="grid grid-cols-2 gap-4 sm:gap-6 mb-8">
                <div className="text-center">
                  <div className="text-3xl font-bold text-sky-400 mb-2">50+</div>
                  <div className="text-slate-400">Projects Completed</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-emerald-400 mb-2">98%</div>
                  <div className="text-slate-400">Client Satisfaction</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-violet-400 mb-2">3x</div>
                  <div className="text-slate-400">Average Speed Improvement</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-orange-400 mb-2">24/7</div>
                  <div className="text-slate-400">Support Available</div>
                </div>
              </div>
            </div>
            
            <div className="space-y-6">
              <h3 className="text-2xl font-bold mb-6">Our Values</h3>
              
              <div className="flex items-start">
                <div className="w-12 h-12 bg-gradient-to-br from-sky-500 to-sky-600 rounded-lg flex items-center justify-center mr-4 flex-shrink-0">
                  <Code className="text-white" size={24} />
                </div>
                <div>
                  <h4 className="text-lg font-semibold mb-2">Code Quality First</h4>
                  <p className="text-slate-400">Every line of code is written with performance, accessibility, and maintainability in mind. We believe in creating websites that not only look great but perform exceptionally.</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="w-12 h-12 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-lg flex items-center justify-center mr-4 flex-shrink-0">
                  <Handshake className="text-white" size={24} />
                </div>
                <div>
                  <h4 className="text-lg font-semibold mb-2">Partnership Approach</h4>
                  <p className="text-slate-400">We work closely with our clients as partners, not just service providers. Your success is our success, and we're invested in your long-term growth.</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="w-12 h-12 bg-gradient-to-br from-violet-500 to-violet-600 rounded-lg flex items-center justify-center mr-4 flex-shrink-0">
                  <TrendingUp className="text-white" size={24} />
                </div>
                <div>
                  <h4 className="text-lg font-semibold mb-2">Results Driven</h4>
                  <p className="text-slate-400">Every design decision is made with conversion and user experience as the primary considerations. We build websites that generate leads and grow businesses.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-20 bg-gradient-vezel">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl sm:text-4xl font-bold mb-8">Our Mission</h2>
          <p className="text-xl text-slate-300 max-w-4xl mx-auto mb-12">
            To empower service-based businesses with custom-coded websites that outperform page builders in every metric that matters: speed, SEO, conversions, and user experience.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-slate-800/50 p-8 rounded-2xl border border-slate-700/50">
              <div className="text-4xl font-bold text-sky-400 mb-4">Fast</div>
              <p className="text-slate-300">Lightning-fast websites that load in under 2 seconds, keeping visitors engaged and improving search rankings.</p>
            </div>
            
            <div className="bg-slate-800/50 p-8 rounded-2xl border border-slate-700/50">
              <div className="text-4xl font-bold text-emerald-400 mb-4">Effective</div>
              <p className="text-slate-300">Conversion-focused designs that turn website visitors into leads and customers for your service business.</p>
            </div>
            
            <div className="bg-slate-800/50 p-8 rounded-2xl border border-slate-700/50">
              <div className="text-4xl font-bold text-violet-400 mb-4">Custom</div>
              <p className="text-slate-300">Every website is built from scratch to match your unique brand and business requirements perfectly.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Why Work With Us */}
      <section className="py-20 bg-slate-800/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">Why Work With Vezel Studio?</h2>
            <p className="text-xl text-slate-300">We're different from other web design agencies</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div>
              <h3 className="text-2xl font-bold mb-6">What Makes Us Different</h3>
              <div className="space-y-6">
                <div>
                  <h4 className="text-lg font-semibold mb-2 text-sky-400">No Page Builders Ever</h4>
                  <p className="text-slate-400">While other agencies use WordPress builders or templates, we hand-code every website for maximum performance and customization.</p>
                </div>
                
                <div>
                  <h4 className="text-lg font-semibold mb-2 text-emerald-400">Service Business Specialists</h4>
                  <p className="text-slate-400">We focus exclusively on service-based businesses and understand their unique marketing challenges and conversion requirements.</p>
                </div>
                
                <div>
                  <h4 className="text-lg font-semibold mb-2 text-violet-400">Performance Obsessed</h4>
                  <p className="text-slate-400">Every website we build is optimized for speed, SEO, and conversions from day one. No bloated code or unnecessary plugins.</p>
                </div>
                
                <div>
                  <h4 className="text-lg font-semibold mb-2 text-orange-400">Long-term Partnership</h4>
                  <p className="text-slate-400">We don't just build websites and disappear. We provide ongoing support, updates, and optimization to ensure continued success.</p>
                </div>
              </div>
            </div>
            
            <div>
              <h3 className="text-2xl font-bold mb-6">Our Process</h3>
              <div className="space-y-6">
                <div className="flex items-start">
                  <div className="w-8 h-8 bg-gradient-to-br from-sky-500 to-sky-600 rounded-lg flex items-center justify-center mr-4 flex-shrink-0 mt-1">
                    <span className="text-white font-bold text-sm">1</span>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">Discovery Call</h4>
                    <p className="text-slate-400 text-sm">We learn about your business, goals, and target customers to create a strategic plan.</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="w-8 h-8 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-lg flex items-center justify-center mr-4 flex-shrink-0 mt-1">
                    <span className="text-white font-bold text-sm">2</span>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">Custom Design</h4>
                    <p className="text-slate-400 text-sm">We create wireframes and designs tailored specifically to your brand and industry.</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="w-8 h-8 bg-gradient-to-br from-violet-500 to-violet-600 rounded-lg flex items-center justify-center mr-4 flex-shrink-0 mt-1">
                    <span className="text-white font-bold text-sm">3</span>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">Development</h4>
                    <p className="text-slate-400 text-sm">Hand-coded development with focus on performance, SEO, and mobile optimization.</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="w-8 h-8 bg-gradient-to-br from-orange-500 to-orange-600 rounded-lg flex items-center justify-center mr-4 flex-shrink-0 mt-1">
                    <span className="text-white font-bold text-sm">4</span>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">Launch & Support</h4>
                    <p className="text-slate-400 text-sm">Seamless launch with ongoing support and optimization to maximize your results.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-vezel">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">Ready to Work Together?</h2>
          <p className="text-xl text-slate-300 mb-8">
            Let's discuss your project and see how we can help your business grow online
          </p>
          <Link href="/contact">
            <Button className="inline-flex items-center bg-gradient-to-r from-sky-500 to-violet-600 text-white px-8 py-4 rounded-xl text-lg font-semibold hover:from-sky-600 hover:to-violet-700 transition-all duration-200 shadow-lg hover:shadow-xl transform hover:scale-105">
              Start Your Project
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}
