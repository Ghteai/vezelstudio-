import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowRight, Rocket, Search, Settings } from "lucide-react";

export default function Hero() {
  return (
    <section className="pt-16 min-h-screen flex items-center bg-gradient-hero">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
        <div className="text-center">
          <div className="animate-fade-in">
            <h1 className="text-3xl sm:text-4xl lg:text-5xl xl:text-6xl font-bold mb-6">
              <span className="block mb-2">Custom Web Design</span>
              <span className="bg-gradient-to-r from-sky-400 via-violet-500 to-emerald-400 bg-clip-text text-transparent">
                Built with Code
              </span>
            </h1>
            <p className="text-lg sm:text-xl lg:text-2xl text-slate-300 mb-8 max-w-4xl mx-auto leading-relaxed px-4">
              We design and redesign websites using actual code — no Wix, no Squarespace, no WordPress builders.
            </p>
          </div>
          
          <div className="animate-slide-up mb-8 sm:mb-12">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 sm:gap-8 max-w-4xl mx-auto mb-8 sm:mb-12">
              <div className="bg-slate-800/50 p-6 rounded-xl border border-slate-700/50">
                <Rocket className="text-sky-400 text-2xl mb-3 mx-auto" size={32} />
                <h3 className="font-semibold mb-2">Faster Load Times</h3>
                <p className="text-slate-400 text-sm">Custom code = optimized performance</p>
              </div>
              <div className="bg-slate-800/50 p-6 rounded-xl border border-slate-700/50">
                <Search className="text-emerald-400 text-2xl mb-3 mx-auto" size={32} />
                <h3 className="font-semibold mb-2">Better SEO</h3>
                <p className="text-slate-400 text-sm">Clean code structure for search engines</p>
              </div>
              <div className="bg-slate-800/50 p-6 rounded-xl border border-slate-700/50">
                <Settings className="text-violet-400 text-2xl mb-3 mx-auto" size={32} />
                <h3 className="font-semibold mb-2">Full Control</h3>
                <p className="text-slate-400 text-sm">Complete customization capabilities</p>
              </div>
            </div>
          </div>

          <div className="animate-slide-up">
            <Link href="/contact">
              <Button className="inline-flex items-center bg-gradient-to-r from-sky-500 to-violet-600 text-white px-8 py-4 rounded-xl text-lg font-semibold hover:from-sky-600 hover:to-violet-700 transition-all duration-200 shadow-lg hover:shadow-xl transform hover:scale-105">
                Get Your Custom Website
                <ArrowRight className="ml-2" size={20} />
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
