import { Link } from "wouter";
import { Twitter, Linkedin, Github } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-slate-950 border-t border-slate-800 py-8 sm:py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6 sm:gap-8">
          <div className="sm:col-span-2 md:col-span-2">
            <h3 className="text-2xl font-bold bg-gradient-to-r from-sky-400 to-violet-500 bg-clip-text text-transparent mb-4">
              Vezel Studio
            </h3>
            <p className="text-slate-400 mb-6 max-w-md">
              Custom web design agency specializing in high-converting websites for service-based businesses. No page builders, just clean, fast code.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="w-10 h-10 bg-slate-800 rounded-lg flex items-center justify-center text-slate-400 hover:text-sky-400 hover:bg-slate-700 transition-all">
                <Twitter size={18} />
              </a>
              <a href="#" className="w-10 h-10 bg-slate-800 rounded-lg flex items-center justify-center text-slate-400 hover:text-sky-400 hover:bg-slate-700 transition-all">
                <Linkedin size={18} />
              </a>
              <a href="#" className="w-10 h-10 bg-slate-800 rounded-lg flex items-center justify-center text-slate-400 hover:text-sky-400 hover:bg-slate-700 transition-all">
                <Github size={18} />
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-4">Services</h4>
            <ul className="space-y-2 text-slate-400">
              <li><Link href="/services"><span className="hover:text-sky-400 transition-colors cursor-pointer">Web Design</span></Link></li>
              <li><Link href="/services"><span className="hover:text-sky-400 transition-colors cursor-pointer">Website Redesign</span></Link></li>
              <li><Link href="/services"><span className="hover:text-sky-400 transition-colors cursor-pointer">Branding</span></Link></li>
              <li><Link href="/services"><span className="hover:text-sky-400 transition-colors cursor-pointer">Logo Design</span></Link></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-4">Company</h4>
            <ul className="space-y-2 text-slate-400">
              <li><Link href="/about"><span className="hover:text-sky-400 transition-colors cursor-pointer">About Us</span></Link></li>
              <li><Link href="/portfolio"><span className="hover:text-sky-400 transition-colors cursor-pointer">Portfolio</span></Link></li>
              <li><Link href="/contact"><span className="hover:text-sky-400 transition-colors cursor-pointer">Contact</span></Link></li>
              <li><a href="#" className="hover:text-sky-400 transition-colors">Privacy Policy</a></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-slate-800 mt-8 pt-8 text-center text-slate-400">
          <p>&copy; 2024 Vezel Studio. All rights reserved. Built with custom code, not page builders.</p>
        </div>
      </div>
    </footer>
  );
}
